# tokio-current-thread

Single threaded executor for Tokio.

[Documentation](https://docs.rs/tokio-current-thread/0.1.6/tokio_current_thread/)

## Overview

This crate provides the single threaded executor which execute many tasks concurrently.

## License

This project is licensed under the [MIT license](LICENSE).

### Contribution

Unless you explicitly state otherwise, any contribution intentionally submitted
for inclusion in Tokio by you, shall be licensed as MIT, without any additional
terms or conditions.
