# ws2_32 #
Contains function definitions for the Windows API library ws2_32. See winapi for types and constants.

```toml
[dependencies]
ws2_32-sys = "0.2.0"
```

```rust
extern crate ws2_32;
```

[Documentation](https://retep998.github.io/doc/ws2_32/)
