# tokio-sync

Synchronization utilities

[Documentation](https://docs.rs/tokio-sync/0.1.6/tokio_sync/)

## Overview

This crate provides synchronization utilities for usage with Tokio.

## License

This project is licensed under the [MIT license](LICENSE).

### Contribution

Unless you explicitly state otherwise, any contribution intentionally submitted
for inclusion in Tokio by you, shall be licensed as MIT, without any additional
terms or conditions.
