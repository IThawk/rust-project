# 0.1.2 (January 26th, 2018)

* Add support for non-windows/unix targets (#10)

# 0.1.1 (October 5th, 2017)

* Fix soundness bug: Assert slice lengths are always > 0 (#5)

# 0.1.0 (March 14th, 2017)

* Initial release
