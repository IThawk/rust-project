# 0.1.1 (September 26, 2018)

* Allow setting max line length with `LinesCodec` (#632)

# 0.1.0 (June 13, 2018)

* Initial release (#353)
