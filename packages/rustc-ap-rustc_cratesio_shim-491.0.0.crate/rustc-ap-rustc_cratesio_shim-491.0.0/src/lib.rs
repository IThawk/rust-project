#![deny(rust_2018_idioms)]

// See Cargo.toml for a comment explaining this crate.
#![allow(unused_extern_crates)]

#![feature(nll)]

extern crate bitflags;
extern crate log;
extern crate proc_macro;
extern crate unicode_width;
