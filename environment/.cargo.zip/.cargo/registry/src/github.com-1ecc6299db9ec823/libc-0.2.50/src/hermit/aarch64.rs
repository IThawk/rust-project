pub type c_char = u8;
pub type wchar_t = u32;
