//! Thread-safe task notification primitives.

mod atomic_task;

pub use self::atomic_task::AtomicTask;
