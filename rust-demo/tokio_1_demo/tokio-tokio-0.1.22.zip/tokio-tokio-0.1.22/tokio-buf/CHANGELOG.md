# 0.1.1 (April 22, 2019)

### Added
- Utilities for creating a `BufStream` from iterators and streams (#1011).
- Add `BufStream::into_stream` (#1048).
- Implement `FromBufStream` for `Bytes` (#1009).
- Implement `Error` for `CollectVecError` (#1010).

### Fixed
- Implement `size_hint` for string types (#1012).

# 0.1.0 (February 23, 2019)

* Initial release
