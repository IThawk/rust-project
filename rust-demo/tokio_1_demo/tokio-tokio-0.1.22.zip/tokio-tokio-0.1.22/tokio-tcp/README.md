# tokio-tcp

TCP bindings for `tokio`.

[Documentation](https://docs.rs/tokio-tcp/0.1.3/tokio_tcp)

## License

This project is licensed under the [MIT license](./LICENSE).

### Contribution

Unless you explicitly state otherwise, any contribution intentionally submitted
for inclusion in Tokio by you, shall be licensed as MIT, without any additional
terms or conditions.
