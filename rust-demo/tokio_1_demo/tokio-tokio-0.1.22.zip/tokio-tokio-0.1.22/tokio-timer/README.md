# tokio-timer

Timer facilities for Tokio

[Documentation](https://docs.rs/tokio-timer/0.2.11/tokio_timer/)

## Overview

This crate provides timer facilities for usage with Tokio.

## License

This project is licensed under the [MIT license](LICENSE).

### Contribution

Unless you explicitly state otherwise, any contribution intentionally submitted
for inclusion in Tokio by you, shall be licensed as MIT, without any additional
terms or conditions.
