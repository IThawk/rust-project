// TODO: write tests using TcpStream::split()
