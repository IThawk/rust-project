//! Utilities for implementing networking types.

mod poll_evented;
pub use self::poll_evented::PollEvented;
