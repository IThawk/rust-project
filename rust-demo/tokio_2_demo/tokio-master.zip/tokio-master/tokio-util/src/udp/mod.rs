//! UDP framing

mod frame;
pub use self::frame::UdpFramed;
