# 0.2.0-alpha.6 (September 30, 2019)

- Move to `futures-*-preview 0.3.0-alpha.19`
- Move to `pin-project 0.4`

# 0.2.0-alpha.5 (September 19, 2019)

- Track tokio release.

# 0.2.0-alpha.4 (August 29, 2019)

- Track tokio release.

# 0.2.0-alpha.3 (August 28, 2019)

### Changed
- track changes to `tokio-timer` (#1471).

# 0.2.0-alpha.2 (August 17, 2019)

### Changed
- Update `futures` dependency to 0.3.0-alpha.18.

# 0.2.0-alpha.1 (August 8, 2019)

- Initial release
